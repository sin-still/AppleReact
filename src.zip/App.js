/* eslint-disable */
// 워닝 없애주는 기능

import { useState } from 'react';
import './App.css';





function App() {
  let post = '강남 우동 맛집'
  let [ logo, setLogo ] = useState('React BLOG')
  let [ title, setTitle ] = useState(['남자 코트 추천', '여자 코드 추천', 'REACT 독학'])
  let [ good, setGood ] = useState(0)
  //[a, b] a = state 저장한 자료 b = state 를 변경할 때 도와주는 함수
  
  //변수와 state 의 차이점
  //변수는 변경이 일어났을 때 랜더링이 일어나지않음. 
  //state 는 변경이 되었을 때 재랜더링이 일어난다.
  //때문에 자주 변경이 될 거 같은 곳에 state를 사용. 


  //let num = [1, 2];
  //let [a, c] = [1, 2;
  //Destructuring(디스럭쳐링 문법): arry안에 요소를 빼주는 문법
  
  function goodFn(){
    setGood(good +1) 
  }

  function titleFn(){
    let newTitle = [...title];
    newTitle[0] = newTitle[0] !== '여자 코트 추천' ? '여자 코트 추천' : '남자 코트 추천';
    setTitle(newTitle)
  }
  // state 를 변경할 땐 set함수를 활용해서 ( ) 안에 집어넣는다.
  
  return (
    <div className="App">
      <div className='black-nav'>
        <h4 style={{color: 'red', fontSize:'16px'}}>{ logo }</h4>
      </div>
      <button onClick={titleFn}>제목 변경</button>
      <div className='list'>
        <h4>{ title[0] } <span onClick={ goodFn } >🧡</span> { good } </h4>
        <p>2월 17일 발행</p>
      </div>
      <div className='list'>
        <h4>{ title[1] }</h4>
        <p>2월 17일 발행</p>
      </div>
      <div className='list'>
        <h4>{ title[2] }</h4>
        <p>2월 17일 발행</p>
      </div>
      <h4>{ post }</h4>

    </div>
  );
}

export default App;
